from django.contrib import admin

from .models import LoginEvent


@admin.register(LoginEvent)
class LoginEventAdmin(admin.ModelAdmin):
    list_display = ('event_type', 'username_attempted', 'user', 'ip_address', 'timestamp')
    list_filter = ('event_type',)
    search_fields = ('username_attempted', 'ip_address')
    readonly_fields = ('event_type', 'user', 'username_attempted', 'ip_address', 'user_agent', 'timestamp')

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
