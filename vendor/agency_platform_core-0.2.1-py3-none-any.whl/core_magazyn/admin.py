from django.contrib import admin
from simple_history.admin import SimpleHistoryAdmin

from .models import Kategoria, Przeglad, PrzedmiotSeryjny, PrzedmiotZbiorczy


@admin.register(Kategoria)
class KategoriaAdmin(admin.ModelAdmin):
    list_display = ('nazwa',)
    search_fields = ('nazwa',)


class PrzegladInlineZbiorczy(admin.TabularInline):
    model = Przeglad
    fk_name = 'przedmiot_zbiorczy'
    extra = 0
    fields = ('data', 'typ', 'opis', 'wykonal', 'dodal')


class PrzegladInlineSeryjny(admin.TabularInline):
    model = Przeglad
    fk_name = 'przedmiot_seryjny'
    extra = 0
    fields = ('data', 'typ', 'opis', 'wykonal', 'dodal')


@admin.register(PrzedmiotZbiorczy)
class PrzedmiotZbiorczyAdmin(SimpleHistoryAdmin):
    list_display = ('nazwa', 'kategoria', 'ilosc_na_stanie', 'jednostka', 'wlasciciel_typ', 'opiekun', 'stan_niski')
    list_filter = ('kategoria', 'wlasciciel_typ', 'jednostka')
    search_fields = ('nazwa',)
    inlines = [PrzegladInlineZbiorczy]

    @admin.display(description='Stan niski', boolean=True)
    def stan_niski(self, obj):
        return obj.stan_niski


@admin.register(PrzedmiotSeryjny)
class PrzedmiotSeryjnyAdmin(SimpleHistoryAdmin):
    list_display = ('nazwa', 'numer_inwentarzowy', 'kategoria', 'stan', 'wlasciciel_typ', 'opiekun')
    list_filter = ('kategoria', 'stan', 'wlasciciel_typ')
    search_fields = ('nazwa', 'numer_inwentarzowy')
    inlines = [PrzegladInlineSeryjny]


@admin.register(Przeglad)
class PrzegladAdmin(admin.ModelAdmin):
    list_display = ('przedmiot_wyswietlany', 'typ', 'data', 'wykonal')
    list_filter = ('typ',)
    search_fields = (
        'przedmiot_zbiorczy__nazwa', 'przedmiot_seryjny__nazwa', 'przedmiot_seryjny__numer_inwentarzowy', 'wykonal',
    )

    @admin.display(description='Przedmiot')
    def przedmiot_wyswietlany(self, obj):
        return obj.przedmiot_zbiorczy or obj.przedmiot_seryjny
