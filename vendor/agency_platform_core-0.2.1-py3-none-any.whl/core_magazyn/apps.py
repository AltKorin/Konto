from django.apps import AppConfig


class CoreMagazynConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core_magazyn'
    verbose_name = 'Magazyn'
